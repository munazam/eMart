﻿using eMart.Application.Interfaces;
using eMart.Domain.Entities;
using eMart.Domain.Exceptions;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace eMart.Application.Identity
{
    public class TokenGeneratorService : ITokenGeneratorService
    {
        private readonly UserManager<User> _userManager;
        private readonly IApplicationConfigurationManager _configuration;
        private readonly IApplicationDbContext _applicationDbContext;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userManager"></param>
        /// <param name="configuration"></param>
        /// <param name="applicationDbContext"></param>
        public TokenGeneratorService(UserManager<User> userManager,
            IApplicationConfigurationManager configuration,
            IApplicationDbContext applicationDbContext)
        {
            _userManager = userManager;
            _configuration = configuration;
            _applicationDbContext = applicationDbContext;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<object> GenerateUserToken(User user)
        {
            var utcNow = DateTime.UtcNow;
            var claims = new List<Claim>
        {
            new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
            new Claim(JwtRegisteredClaimNames.UniqueName, user.UserName),
            new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new Claim(ClaimTypes.Name, user.UserName),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
        };

            var userRoles = await _userManager.GetRolesAsync(user);
            foreach (var userRole in userRoles)
                claims.Add(new Claim(ClaimTypes.Role, userRole));

            var signingKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration.Tokens.SecretKey));
            var signingCredentials = new SigningCredentials(signingKey, SecurityAlgorithms.HmacSha512);
            var jwt = new JwtSecurityToken(
                    signingCredentials: signingCredentials,
            claims: claims,
                    notBefore: utcNow,
                    expires: utcNow.AddMinutes(_configuration.Tokens.TokenLifeTime),
                    audience: _configuration.Tokens.Issuer,
                    issuer: _configuration.Tokens.Issuer);

            return await BuildTokenObject(user, userRoles.ToList(), jwt, utcNow);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="refreshTokenKey"></param>
        /// <returns></returns> 
        public async Task<object> GenerateUserTokenByRefreshToken(string refreshTokenKey)
        {

            var user = await ValidateRefreshToken(refreshTokenKey);
            return await GenerateUserToken(user);
        }


        #region Private Methods
        private async Task<User> ValidateRefreshToken(string protectedTicket)
        {
            var refreshToken = await _applicationDbContext.UserRefreshTokens
                .Include(r => r.User)
                .FirstOrDefaultAsync(r => r.ProtectedTicket == protectedTicket);

            if (refreshToken == null)
                throw new BusinessException("Invalid refresh token");

            if (refreshToken.ExpiresUtc < DateTime.UtcNow)
                throw new BusinessException("Refresh token is expired");

            if (refreshToken.User.IsActive == false)
                throw new BusinessException("User is not active");

            _applicationDbContext.UserRefreshTokens.Remove(refreshToken);
            await _applicationDbContext.SaveChangesAsync();

            return refreshToken.User;
        }
        private async Task<object> BuildTokenObject(User user, List<string> userRoles, JwtSecurityToken jwt, DateTime utcNow)
        {
            var refreshToken = await GenerateRefreshToken(user.Id);
            var roles = await _userManager.GetRolesAsync(user);
            var token = new
            {
                access_token = new JwtSecurityTokenHandler().WriteToken(jwt),
                token_type = "bearer",
                expires_in = utcNow.AddMinutes(_configuration.Tokens.TokenLifeTime),
                refresh_token = refreshToken,
                userName = user.UserName,
                name = user.FullName,
                email = user.Email,
                roles = roles.ToList(),
                issued = utcNow,
                expires = utcNow.AddMinutes(_configuration.Tokens.TokenLifeTime),
            };

            return token;
        }
        private async Task<string> GenerateRefreshToken(Guid UserId)
        {
            var refreshToken = new UserRefreshToken(UserId, _configuration.Tokens.RefreshTokenLifeTime);

            await _applicationDbContext.UserRefreshTokens.AddAsync(refreshToken);
            await _applicationDbContext.SaveChangesAsync();

            return refreshToken.ProtectedTicket;
        }
        #endregion
    }
}
