﻿using eMart.Application.Common.Models;

namespace eMart.Application.Interfaces
{
    public interface IApplicationConfigurationManager
    {
        TokenConfiguration Tokens { get; }
        IdentityOption IdentityOptions { get; }
    }
}
