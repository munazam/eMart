﻿using eMart.Domain.Enums;

namespace eMart.Application.Interfaces
{
    public interface IAppNLogger
    {
        void Log(LoggerActionType actionType, string message, string anonymousUsername = null, string details = null, Guid? key = null);
    }
}
