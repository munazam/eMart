﻿namespace eMart.Application.Interfaces
{
    public interface IAccountService
    {
        Guid GetLoggedInUserId();
        string GetLoggedInUserName();
    }
}
