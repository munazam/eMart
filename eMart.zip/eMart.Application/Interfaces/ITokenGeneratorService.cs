﻿using eMart.Domain.Entities;

namespace eMart.Application.Interfaces
{
    public interface ITokenGeneratorService
    {
        Task<object> GenerateUserToken(User user);
        Task<object> GenerateUserTokenByRefreshToken(string refreshTokenKey);
    }
}
