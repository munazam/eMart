﻿using eMart.Application.Interfaces;

namespace eMart.Application.Common.Models
{
    public class ApplicationConfigurationManager : IApplicationConfigurationManager
    {
        public TokenConfiguration Tokens { get; set; }
        public IdentityOption IdentityOptions { get; set; }
    }

    public class TokenConfiguration
    {
        public string SecretKey { get; set; }

        public string Issuer { get; set; }

        public string Audience { get; set; }

        public string TokenPath { get; set; }

        public string CookieName { get; set; }

        public int TokenLifeTime { get; set; }

        public int RefreshTokenLifeTime { get; set; }

        public bool UseRandomOTP { get; set; }
    }

    public class IdentityOption
    {
        public int DefaultLockoutMinutes { get; set; }
        public int MaxFailedAccessAttempts { get; set; }
    }
}
