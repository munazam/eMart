﻿using eMart.Domain.Enums;
using System.ComponentModel.DataAnnotations;

namespace eMart.Application.Common.Pagination
{
    public abstract class PaginationQuery
    {

        public SortingDirectionType SortingDirection { get; set; } = SortingDirectionType.Ascending;
        [Range(1, int.MaxValue)]
        public int PageNumber { get; init; } = 1;
        [Range(1, 200)]
        public int PageSize { get; init; } = 20;
    }
}
