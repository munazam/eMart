﻿using System.Runtime.Serialization;

namespace eMart.Application.Common.Exceptions
{
    [Serializable]
    public class NotAllowedActionException : Exception
    {
        public NotAllowedActionException()
        {

        }

        public NotAllowedActionException(string message) : base(message)
        {
        }

        public NotAllowedActionException(string message, Exception innerException) : base(message, innerException)
        {
        }

    }

}
