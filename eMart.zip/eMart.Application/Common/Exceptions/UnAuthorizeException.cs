﻿using System.Runtime.Serialization;

namespace eMart.Application.Common.Exceptions
{
    [Serializable]
    public class UnAuthorizeException : Exception
    {
        public UnAuthorizeException()
        {

        }

        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);
        }
    }
}