﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using eMart.Application.Common.Pagination;
using Microsoft.EntityFrameworkCore;

namespace eMart.Application.Common.Mappings
{
    public static class MappingExtensions
    {
        public static Task<PaginationResult<TDestination>> PaginatedListAsync<TDestination>(this IQueryable<TDestination> queryable, int pageNumber, int pageSize, CancellationToken cancellationToken = default) where TDestination : class
            => PaginationResult<TDestination>.CreateAsync(queryable.AsNoTracking(), pageNumber, pageSize, cancellationToken);

        public static Task<List<TDestination>> ProjectToListAsync<TDestination>(this IQueryable queryable, IConfigurationProvider configuration, CancellationToken cancellationToken = default) where TDestination : class
            => queryable.ProjectTo<TDestination>(configuration).AsNoTracking().ToListAsync(cancellationToken);
    }
}
