﻿using eMart.Application.Interfaces;
using eMart.Domain.Entities;
using eMart.Domain.Exceptions;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace eMart.Application.Features.Carts.Commands;
public class AddItemCommand : IRequest
{
    public Guid ProductId { get; set; }
    public int Quantity { get; set; }
}

public class AddItemCommandHander(IAccountService accountService, IApplicationDbContext dbContext) : IRequestHandler<AddItemCommand>
{
    public async Task Handle(AddItemCommand request, CancellationToken cancellationToken)
    {
        var product = await dbContext.Products.FirstOrDefaultAsync(p => p.ProductId == request.ProductId, cancellationToken: cancellationToken) ?? throw new BusinessException("Product not available");
        
        var cart = await GetCart(accountService, dbContext, cancellationToken);

        cart.Add(product, request.Quantity);

        await dbContext.SaveChangesAsync(cancellationToken);

    }

    private static async Task<Cart> GetCart(IAccountService accountService, IApplicationDbContext dbContext, CancellationToken cancellationToken)
    {
        var loggedInUserId = accountService.GetLoggedInUserId();

        var cart = await dbContext.Carts
                    .Include(c => c.CartItems).ThenInclude(i => i.Product)
                    .FirstOrDefaultAsync(c => c.UserId == loggedInUserId, cancellationToken: cancellationToken);

        if (cart == null)
        {
            var user = await dbContext.Users.FirstOrDefaultAsync(u => u.Id == loggedInUserId, cancellationToken: cancellationToken);

            cart = new Cart(user);

            await dbContext.Carts.AddAsync(cart, cancellationToken);
        }

        return cart;
    }
}
