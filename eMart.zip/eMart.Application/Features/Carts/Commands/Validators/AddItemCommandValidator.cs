﻿using FluentValidation;

namespace eMart.Application.Features.Carts.Commands.Validators;
public class AddItemCommandValidator : AbstractValidator<AddItemCommand>
{
    public AddItemCommandValidator()
    {
        RuleFor(model => model.Quantity)
            .NotEmpty()
            .GreaterThan(0);

    }
}
