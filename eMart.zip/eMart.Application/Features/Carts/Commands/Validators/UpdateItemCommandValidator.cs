﻿using FluentValidation;

namespace eMart.Application.Features.Carts.Commands.Validators;
public class UpdateItemCommandValidator : AbstractValidator<UpdateItemCommand>
{
    public UpdateItemCommandValidator()
    {
        RuleFor(model => model.Quantity)
            .NotEmpty()
            .GreaterThan(0);

    }
}
