﻿using eMart.Application.Interfaces;
using eMart.Domain.Entities;
using eMart.Domain.Exceptions;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace eMart.Application.Features.Carts.Commands;
public class UpdateItemCommand : IRequest
{
    public Guid ProductId { get; set; }
    public int Quantity { get; set; }
}

public class UpdateItemCommandHander(IAccountService accountService, IApplicationDbContext dbContext) : IRequestHandler<UpdateItemCommand>
{
    public async Task Handle(UpdateItemCommand request, CancellationToken cancellationToken)
    {
        var product = await dbContext.Products.FirstOrDefaultAsync(p => p.ProductId == request.ProductId, cancellationToken: cancellationToken) ?? throw new BusinessException("Product not available");
        
        var cart = await GetCart(accountService, dbContext, cancellationToken);

        cart.UpdateProductQuantity(product, request.Quantity);

        await dbContext.SaveChangesAsync(cancellationToken);
    }

    private static async Task<Cart> GetCart(IAccountService accountService, IApplicationDbContext dbContext, CancellationToken cancellationToken)
    {
        var loggedInUserId = accountService.GetLoggedInUserId();

        var cart = await dbContext.Carts
                    .Include(c => c.CartItems).ThenInclude(i => i.Product)
                    .FirstOrDefaultAsync(c => c.UserId == loggedInUserId, cancellationToken: cancellationToken);

        if (cart == null || cart.CartItems.Any() == false)
            throw new BusinessException("Cart is empty");

        return cart;
    }
}
