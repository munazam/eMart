﻿using AutoMapper;
using eMart.Application.Features.Carts.Queries.Models;
using eMart.Application.Interfaces;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace eMart.Application.Features.Carts.Queries;
public record CartQuery() : IRequest<CartViewModel>;

public class CartQueryHandler(IAccountService accountService, IApplicationDbContext dbContext, IMapper mapper) : IRequestHandler<CartQuery, CartViewModel>
{
    public async Task<CartViewModel> Handle(CartQuery request, CancellationToken cancellationToken)
    {
        var loggedInUserId = accountService.GetLoggedInUserId();

        var cart = await dbContext.Carts
                    .Include(c => c.CartItems).ThenInclude(i => i.Product)
                    .FirstOrDefaultAsync(c => c.UserId == loggedInUserId, cancellationToken: cancellationToken);

        return mapper.Map<CartViewModel>(cart);
    }
}
