﻿using eMart.Application.Common.Mappings;
using eMart.Application.Features.Products.Queries.Models;
using eMart.Domain.Entities;

namespace eMart.Application.Features.Carts.Queries.Models;
public class CartViewModel : IMapFrom<Cart>
{
    public decimal Total 
    {
        get 
        {
            return CartItems.Sum(s => s.Product.Price * s.Quantity);
        } 
    }

    public IEnumerable<CartItemViewModel> CartItems { get; set; }
}

public class CartItemViewModel : IMapFrom<CartItem>
{
    public ProductViewModel Product { get; set; }
    public int Quantity { get; set; }
}
