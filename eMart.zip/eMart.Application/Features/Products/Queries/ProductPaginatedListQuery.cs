﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using eMart.Application.Common.Mappings;
using eMart.Application.Common.Pagination;
using eMart.Application.Features.Products.Queries.Models;
using eMart.Application.Interfaces;
using eMart.Domain.Entities;
using eMart.Domain.Enums;
using MediatR;
using System.Linq.Expressions;
using static eMart.Application.Features.Products.Queries.ProductPaginatedListQuery;

namespace eMart.Application.Features.Products.Queries;
public class ProductPaginatedListQuery : PaginationQuery, IRequest<PaginationResult<ProductViewModel>>
{
    public string Name { get; set; }
    public decimal? MinPrice { get; set; }
    public decimal? MaxPrice { get; set; }

    public ProductSorting Sorting { get; set; } = ProductSorting.New;

    public enum ProductSorting
    {
        Name,
        Price,
        New,
    }
}

public class ProductPaginatedListQueryHandler(IApplicationDbContext dbContext, IMapper mapper) : IRequestHandler<ProductPaginatedListQuery, PaginationResult<ProductViewModel>>
{
    public async Task<PaginationResult<ProductViewModel>> Handle(ProductPaginatedListQuery request, CancellationToken cancellationToken)
    {
        var query = GetProductsQuery(request);

        query = ApplySorting(query, request);

        return await query
            .ProjectTo<ProductViewModel>(mapper.ConfigurationProvider)
            .PaginatedListAsync(request.PageNumber, request.PageSize);
    }

    private IQueryable<Product> GetProductsQuery(ProductPaginatedListQuery request)
    {
        var query = dbContext.Products.AsQueryable();

        if (!string.IsNullOrEmpty(request.Name))
            query = query.Where(c => c.Name.ToLower().Contains(request.Name.ToLower()));

        if (request.MinPrice.HasValue)
            query = query.Where(c => c.Price >= request.MinPrice);

        if (request.MaxPrice.HasValue)
            query = query.Where(c => c.Price <= request.MaxPrice);

        return query;
    }

    private static IQueryable<Product> ApplySorting(IQueryable<Product> query, ProductPaginatedListQuery request)
    {
        Expression<Func<Product, object>> orderBy = request.Sorting switch
        {
            ProductSorting.New => x => x.Created,
            ProductSorting.Name => x => x.Name,
            ProductSorting.Price => x => x.Price,
            _ => x => x.Created
        };

        query = request.SortingDirection == SortingDirectionType.Ascending ? query.OrderBy(orderBy) : query.OrderByDescending(orderBy);

        return query;
    }
}