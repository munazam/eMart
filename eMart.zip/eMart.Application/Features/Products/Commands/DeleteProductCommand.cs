﻿using eMart.Application.Common.Exceptions;
using eMart.Application.Interfaces;
using eMart.Domain.Exceptions;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace eMart.Application.Features.Products.Commands;
public record DeleteProductCommand(Guid ProductId) : IRequest;

public class DeleteProductCommandHandler(IApplicationDbContext dbContext) : IRequestHandler<DeleteProductCommand>
{
    public async Task Handle(DeleteProductCommand request, CancellationToken cancellationToken)
    {
        var product = await dbContext.Products.FirstOrDefaultAsync(p => p.ProductId == request.ProductId, cancellationToken: cancellationToken) ?? throw new BusinessException("Product does not exists");

        product.Delete();

        await dbContext.SaveChangesAsync(cancellationToken);
    }
}