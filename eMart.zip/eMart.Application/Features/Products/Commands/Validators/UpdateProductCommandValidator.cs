﻿using FluentValidation;

namespace eMart.Application.Features.Products.Commands.Validators;
public class UpdateProductCommandValidator : AbstractValidator<UpdateProductCommand>
{
    public UpdateProductCommandValidator()
    {
        RuleFor(model => model.Name)
            .NotEmpty();

        RuleFor(model => model.Price)
            .NotEmpty()
            .GreaterThan(0);

        RuleFor(model => model.Quantity)
            .NotEmpty()
            .GreaterThan(0);

    }
}
