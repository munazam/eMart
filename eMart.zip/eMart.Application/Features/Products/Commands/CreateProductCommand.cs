﻿using eMart.Application.Interfaces;
using eMart.Domain.Entities;
using MediatR;

namespace eMart.Application.Features.Products.Commands;
public class CreateProductCommand : IRequest
{
    public string Name { get; set; }
    public string Description { get; set; }
    public decimal Price { get; set; }
    public int Quantity { get; set; }
}

public class CreateProductCommandHandler(IApplicationDbContext dbContext) : IRequestHandler<CreateProductCommand>
{
    public async Task Handle(CreateProductCommand request, CancellationToken cancellationToken)
    {
        var product = new Product(request.Name, request.Description, request.Price, request.Quantity);

        await dbContext.Products.AddAsync(product, cancellationToken);

        await dbContext.SaveChangesAsync(cancellationToken);
    }
}