﻿using eMart.Application.Common.Exceptions;
using eMart.Application.Interfaces;
using eMart.Domain.Exceptions;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace eMart.Application.Features.Products.Commands;
public class UpdateProductCommand : IRequest
{
    public Guid ProductId { get; set; }
    public string Name { get; set; }
    public string Description { get; set; }
    public decimal Price { get; set; }
    public int Quantity { get; set; }
}

public class UpdateProductCommandHandler(IApplicationDbContext dbContext) : IRequestHandler<UpdateProductCommand>
{
    public async Task Handle(UpdateProductCommand request, CancellationToken cancellationToken)
    {
        var product = await dbContext.Products.FirstOrDefaultAsync(p => p.ProductId == request.ProductId, cancellationToken: cancellationToken) ?? throw new BusinessException("Product doest not exists");

        product.Update(request.Name, request.Description, request.Price, request.Quantity);

        await dbContext.SaveChangesAsync(cancellationToken);
    }
}