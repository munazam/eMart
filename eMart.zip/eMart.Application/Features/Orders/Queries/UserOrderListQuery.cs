﻿using AutoMapper;
using eMart.Application.Features.Orders.Queries.Models;
using eMart.Application.Interfaces;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace eMart.Application.Features.Orders.Queries;
public record UserOrderListQuery() : IRequest<IEnumerable<OrderViewModel>>;

public class UserOrderListQueryHanlder(IAccountService accountService, IApplicationDbContext dbContext, IMapper mapper) : IRequestHandler<UserOrderListQuery, IEnumerable<OrderViewModel>>
{
    public async Task<IEnumerable<OrderViewModel>> Handle(UserOrderListQuery request, CancellationToken cancellationToken)
    {
        var loggedInUserId = accountService.GetLoggedInUserId();

        var orders = await dbContext.Orders
                    .Include(c => c.OrderItems)
                    .Where(c => c.UserId == loggedInUserId)
                    .ToListAsync(cancellationToken: cancellationToken);

        return mapper.Map<IEnumerable<OrderViewModel>>(orders);
    }
}