﻿using eMart.Application.Common.Mappings;
using eMart.Domain.Entities;

namespace eMart.Application.Features.Orders.Queries.Models;
public class OrderViewModel : IMapFrom<Order>
{
    public Guid OrderId { get; set; }
    public decimal Shipping { get; set; }
    public decimal Tax { get; set; }
    public string AddressName { get; set; }
    public string MobileNumber { get; set; }
    public string AddressLine1 { get; set; }
    public string AddressLine2 { get; set; }
    public decimal Total { get; set; }
    public DateTime Created { get; set; }
    public decimal TotalIncludingTaxAndShipping { get { return Total + Tax + Shipping; } }

    public IEnumerable<OrderItemViewModel> OrderItems { get; set; }
}

public class OrderItemViewModel : IMapFrom<OrderItem>
{
    public int Quantity { get; set; }
    public string ProductName { get; set; }
    public decimal Price { get; set; }
}
