﻿using AutoMapper;
using eMart.Application.Features.Orders.Queries.Models;
using eMart.Application.Interfaces;
using eMart.Domain.Exceptions;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace eMart.Application.Features.Orders.Queries;
public record UserOrderByIdQuery(Guid OrderId) : IRequest<OrderViewModel>;

public class UserOrderByIdQueryHanlder(IAccountService accountService, IApplicationDbContext dbContext, IMapper mapper) : IRequestHandler<UserOrderByIdQuery, OrderViewModel>
{
    public async Task<OrderViewModel> Handle(UserOrderByIdQuery request, CancellationToken cancellationToken)
    {
        var loggedInUserId = accountService.GetLoggedInUserId();

        var order = await dbContext.Orders
                    .Include(c => c.OrderItems)
                    .FirstOrDefaultAsync(c => c.UserId == loggedInUserId && c.OrderId == request.OrderId, cancellationToken: cancellationToken) ?? throw new BusinessException("Order not found");

        return mapper.Map<OrderViewModel>(order);
    }
}
