﻿using eMart.Application.Interfaces;
using eMart.Domain.Entities;
using eMart.Domain.Exceptions;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace eMart.Application.Features.Orders.Commands;
public class CheckoutCommand : IRequest
{
    public bool CheckOutWithAllItems { get; set; }
    public List<Guid> SelectedProductIds { get; set; }
    public string Name { get; set; }
    public string MobileNumber { get; set; }
    public string AddressLine1 { get; set; }
    public string AddressLine2 { get; set; }
}

public class CheckoutCommandHandler(IAccountService accountService, IApplicationDbContext dbContext) : IRequestHandler<CheckoutCommand>
{
    public async Task Handle(CheckoutCommand request, CancellationToken cancellationToken)
    {
        var cart = await GetCart(accountService, dbContext, cancellationToken);

        if (request.CheckOutWithAllItems)
            request.SelectedProductIds = cart.CartItems.Select(s => s.ProductId).ToList();

        var order = new Order(cart, request.SelectedProductIds, request.Name, request.MobileNumber, request.AddressLine1, request.AddressLine2);

        await dbContext.Orders.AddAsync(order, cancellationToken);

        await dbContext.SaveChangesAsync(cancellationToken);
    }

    static async Task<Cart> GetCart(IAccountService accountService, IApplicationDbContext dbContext, CancellationToken cancellationToken)
    {
        var loggedInUserId = accountService.GetLoggedInUserId();

        var cart = await dbContext.Carts
                    .Include(c => c.CartItems).ThenInclude(i => i.Product)
                    .Include(c => c.User)
                    .FirstOrDefaultAsync(c => c.UserId == loggedInUserId, cancellationToken: cancellationToken);

        if (cart == null || cart.CartItems.Any() == false)
            throw new BusinessException("Cart is empty");

        return cart;
    }
}
