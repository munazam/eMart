﻿using FluentValidation;

namespace eMart.Application.Features.Orders.Commands.Validators;
public class CheckoutCommandValidator : AbstractValidator<CheckoutCommand>
{
    public CheckoutCommandValidator()
    {
        RuleFor(model => model.SelectedProductIds)
            .NotEmpty().When(model => model.CheckOutWithAllItems == false).WithMessage("Please select product(s) to checkout");

        RuleFor(model => model.Name)
            .NotEmpty();

        RuleFor(model => model.MobileNumber)
            .NotEmpty();

        RuleFor(model => model.AddressLine1)
            .NotEmpty();

    }
}
