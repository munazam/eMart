﻿using eMart.Application.Interfaces;
using eMart.Domain.Entities;
using eMart.Domain.Exceptions;
using MediatR;
using Microsoft.AspNetCore.Identity;

namespace eMart.Application.Features.Account.Commands;
public class RegisterCommand : IRequest
{
    public string FullName { get; set; }
    public string Email { get; set; }
    public string PhoneNumber { get; set; }
    public string Password { get; set; }
}

public class RegisterCommandHandler : IRequestHandler<RegisterCommand>
{
    private readonly UserManager<User> _userManager;

    public RegisterCommandHandler(UserManager<User> userManager)
    {
        _userManager = userManager;
    }

    public async Task Handle(RegisterCommand request, CancellationToken cancellationToken)
    {
        var user = await _userManager.FindByNameAsync(request.Email);
        if (user != null)
            throw new BusinessException("Email already exists");

        user = new User(request.Email, request.FullName, request.Email, request.PhoneNumber);

        var createUserResult = await _userManager.CreateAsync(user, request.Password);
        if (!createUserResult.Succeeded)
        {

        }
    }
}
