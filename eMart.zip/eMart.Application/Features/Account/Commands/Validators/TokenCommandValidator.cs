﻿using FluentValidation;

namespace eMart.Application.Features.Account.Commands.Validators;

public class TokenCommandValidator : AbstractValidator<TokenCommand>
{
    public TokenCommandValidator()
    {
        RuleFor(model => model.UserName)
            .NotNull()
            .NotEmpty();

        RuleFor(model => model.Password)
            .NotNull()
            .NotEmpty();
    }
}
