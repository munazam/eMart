﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eMart.Application.Features.Account.Commands.Validators;
public class RegisterCommandValidator : AbstractValidator<RegisterCommand>
{
    public RegisterCommandValidator()
    {
        RuleFor(model => model.FullName)
            .NotEmpty();

        RuleFor(model => model.Email)
            .EmailAddress()
            .NotEmpty();

        RuleFor(model => model.Password)
            .MinimumLength(8)
            .NotEmpty();

        RuleFor(model => model.PhoneNumber)
            .NotEmpty();

    }
}
