﻿using eMart.Application.Interfaces;
using MediatR;
using System.ComponentModel.DataAnnotations;

namespace eMart.Application.Features.Account.Commands
{
    public class RefreshTokenCommand : IRequest<object>
    {
        [Required]
        public string RefreshToken { get; set; }
    }
    public class RefreshTokenCommandHandler(ITokenGeneratorService tokenGeneratorService) : IRequestHandler<RefreshTokenCommand, object>
    {
        public async Task<object> Handle(RefreshTokenCommand request, CancellationToken cancellationToken)
        {
            return await tokenGeneratorService.GenerateUserTokenByRefreshToken(request.RefreshToken);
        }
    }
}
