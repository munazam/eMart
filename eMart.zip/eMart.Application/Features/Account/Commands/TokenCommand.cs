﻿using eMart.Application.Interfaces;
using eMart.Domain.Entities;
using eMart.Domain.Exceptions;
using MediatR;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace eMart.Application.Features.Account.Commands
{
    public class TokenCommand : IRequest<object>
    {
        [Required]
        public string UserName { get; set; }
        [Required]
        public string Password { get; set; }
    }

    public class TokenCommandHandler(ITokenGeneratorService tokenGeneratorService,
        UserManager<User> userManager,
        SignInManager<User> signInManager) : IRequestHandler<TokenCommand, object>
    {
        public async Task<object> Handle(TokenCommand request, CancellationToken cancellationToken)
        {
            var user = await Authenticate(request);
            return await tokenGeneratorService.GenerateUserToken(user);
        }

        #region Private Methods
        private async Task<User> Authenticate(TokenCommand request)
        {
            if (request == null)
                throw new BusinessException("Invalid login credentials");

            var user = await userManager.FindByNameAsync(request.UserName);
            if (user == null)
                throw new BusinessException("User is not registered");

            if (user.IsActive == false)
                throw new BusinessException("User is not active");

            var isValidCredintials = await signInManager.CheckPasswordSignInAsync(user, request.Password, false);
            if (isValidCredintials.Succeeded == false)
                throw new BusinessException("Invalid login credentials");

            user.MarkAsLoggedIn();

            await userManager.UpdateAsync(user);

            return user;

        }

        #endregion
    }
}