﻿using eMart.Application.Interfaces;
using eMart.Domain.Enums;
using eMart.Domain.Events.UserEvents;
using MediatR;

namespace eMart.Application.Features.Account.Handlers;
public class UserRegisterEventHandler : INotificationHandler<UserRegisterEvent>
{
    private readonly IAppNLogger _logger;

    public UserRegisterEventHandler(IAppNLogger logger)
    {
        _logger = logger;
    }
    public Task Handle(UserRegisterEvent notification, CancellationToken cancellationToken)
    {
        _logger.Log(LoggerActionType.Login, $"New user '{notification.User.UserName}' registered", key: notification.User.Id);

        return Task.CompletedTask;
    }
}