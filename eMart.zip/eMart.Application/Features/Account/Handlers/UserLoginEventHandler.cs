﻿using eMart.Application.Interfaces;
using eMart.Domain.Enums;
using eMart.Domain.Events.UserEvents;
using MediatR;

namespace eMart.Application.Features.Account.Handlers;
public class UserLoginEventHandler : INotificationHandler<UserLoginEvent>
{
    private readonly IAppNLogger _logger;

    public UserLoginEventHandler(IAppNLogger logger)
    {
        _logger = logger;
    }
    public Task Handle(UserLoginEvent notification, CancellationToken cancellationToken)
    {
        _logger.Log(LoggerActionType.Login, $"User '{notification.User.UserName}' Logged In", key: notification.User.Id);

        return Task.CompletedTask;
    }
}