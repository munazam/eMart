﻿using eMart.Domain.Enums;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;

namespace eMart.API.Filters
{
    /// <summary>
    /// 
    /// </summary>
    /// 
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true, Inherited = true)]

    public class ApiPermissionFilterAttribute : AuthorizeAttribute
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="rolesToCheck"></param>
        public ApiPermissionFilterAttribute(params RoleTypes[] rolesToCheck)
        {
            AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme;
            if (rolesToCheck.Any())
                Roles = string.Join(',', rolesToCheck.Select(s => s.ToString()).ToArray());
        }

    }
}