using eMart.API.Filters;
using eMart.API.Middlewares;
using eMart.API.Services;
using eMart.Application;
using eMart.Application.Common.Models;
using eMart.Application.Interfaces;
using eMart.Infrastructure;
using eMart.Infrastructure.Persistence;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using NLog;
using NLog.Web;
using System.Reflection;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
var configuration = new ApplicationConfigurationManager();
builder.Configuration.Bind(configuration);
builder.Services.AddSingleton<IApplicationConfigurationManager>(configuration);

builder.Services.AddAuthentication(builder.Configuration);
builder.Services.AddApplicationServices();
builder.Services.AddInfrastructureServices();
builder.Services.AddDatabaseContext(builder.Configuration);
builder.Services.AddMemoryCache();
builder.Services.AddResponseCaching();

builder.Services.AddHttpContextAccessor();
builder.Services.AddHealthChecks().AddDbContextCheck<ApplicationDbContext>();
builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
builder.Services.AddMediatR(x => x.RegisterServicesFromAssembly(Assembly.GetExecutingAssembly()));
builder.Services.AddCors(builder.Configuration);

builder.Services.AddSwagger();

builder.Services
    .AddControllers(options => options.Filters.Add<ApiExceptionFilterAttribute>())
    .AddNewtonsoftJson(options =>
    {
        options.SerializerSettings.DateTimeZoneHandling = DateTimeZoneHandling.Local;
        options.SerializerSettings.Converters.Add(new Newtonsoft.Json.Converters.StringEnumConverter());
    });

builder.Services.Configure<ApiBehaviorOptions>(options => options.SuppressModelStateInvalidFilter = true);
builder.Services.AddScoped<IAccountService, AccountService>();

builder.WebHost.UseNLog();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    using (var scope = app.Services.CreateScope())
    {
        var initialiser = scope.ServiceProvider.GetRequiredService<ApplicationDbContextInitialiser>();
        await initialiser.SeedAsync();
    }
}

app.UseHttpsRedirection();

app.UseHealthChecks("/health");

app.UseSwagger(builder.Configuration);

var options = app.Services.GetService<IOptions<RequestLocalizationOptions>>();
app.UseRequestLocalization(options.Value);
app.UseExceptionHandler(ExceptionsHandlerMiddleware.HandleApplicationExceptions());

app.UseDefaultFiles();
app.UseStaticFiles();
app.UseRouting();
app.UseCors("CorsPolicy");
app.UseAuthentication();
app.UseAuthorization();
app.UseResponseCaching();

app.MapControllers();

LogManager.Setup().LoadConfigurationFromFile("nlog.config");
LogManager.Configuration.Variables["logConnectionstring"] = builder.Configuration.GetConnectionString("LogDatabaseConnection");

app.Run();
