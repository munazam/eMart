﻿using eMart.Application.Common.Exceptions;
using eMart.Application.Interfaces;
using System.Security.Claims;

namespace eMart.API.Services
{
    /// <summary>
    /// 
    /// </summary>
    public class AccountService : IAccountService
    {
        #region Members

        private readonly IHttpContextAccessor _httpContextAccessor;

        #endregion

        #region Constructors
        /// <summary>
        /// 
        /// </summary>
        /// <param name="httpContextAccessor"></param>
        public AccountService(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        #endregion

        #region Services



        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        /// <exception cref="UnAuthorizeException"></exception>
        public Guid GetLoggedInUserId()
        {
            var principal = _httpContextAccessor.HttpContext.User;
            if (principal == null)
                throw new UnAuthorizeException();

            var loggedInUserId = principal.FindFirstValue(ClaimTypes.NameIdentifier);
            if (loggedInUserId == null)
                throw new UnAuthorizeException();

            return Guid.Parse(loggedInUserId);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException"></exception>
        public string GetLoggedInUserName()
        {
            if (_httpContextAccessor == null)
                return string.Empty;
            var principal = _httpContextAccessor.HttpContext.User;
            if (principal == null)
                throw new ArgumentNullException(nameof(principal));

            var loggedInUserName = principal.FindFirstValue(ClaimTypes.Name);
            return loggedInUserName;
        }

        #endregion
    }
}