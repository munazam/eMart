﻿namespace Microsoft.Extensions.DependencyInjection;

/// <summary>
/// 
/// </summary>
public static class ConfigureCorsServices
{
    /// <summary>
    /// 
    /// </summary>
    /// <param name="services"></param>
    /// <param name="configuration"></param>
    /// <returns></returns>
    public static IServiceCollection AddCors(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddCors(options =>
        {
            options.AddPolicy("CorsPolicy",
                builder => builder
                .WithOrigins(configuration["AllowedCORS"].Split(";"))
                .AllowAnyMethod()
                .AllowAnyHeader()
                .AllowCredentials()
                );
        });

        return services;
    }
}
