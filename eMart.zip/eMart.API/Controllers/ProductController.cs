﻿using eMart.API.Controllers.Base;
using eMart.API.Filters;
using eMart.Application.Common.Pagination;
using eMart.Application.Features.Products.Commands;
using eMart.Application.Features.Products.Queries;
using eMart.Application.Features.Products.Queries.Models;
using eMart.Domain.Enums;
using Microsoft.AspNetCore.Mvc;

namespace eMart.API.Controllers;

/// <summary>
/// Manage Products
/// </summary>
public class ProductController : ApiControllerBase
{
    /// <summary>
    /// get pagination list of products based on search cirteria 
    /// </summary>
    /// <param name="model"></param>
    /// <returns></returns>
    [HttpGet]
    [Route("Search")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PaginationResult<ProductViewModel>))]
    public async Task<IActionResult> Search([FromQuery] ProductPaginatedListQuery model)
    {
        var products = await Mediator.Send(model);
        return Ok(products);
    }

    /// <summary>
    /// Add new product in the inventory
    /// </summary>
    /// <param name="model"></param>
    /// <returns></returns>
    [HttpPost]
    [ApiPermissionFilter(RoleTypes.ProductCreate)]
    public async Task<IActionResult> Post(CreateProductCommand model)
    {
        await Mediator.Send(model);
        return Ok();
    }

    /// <summary>
    /// Update product in the inventory
    /// </summary>
    /// <param name="productId"></param>
    /// <param name="model"></param>
    /// <returns></returns>
    [HttpPut]
    [Route("{productId}")]
    [ApiPermissionFilter(RoleTypes.ProductUpdate)]
    public async Task<IActionResult> Put(Guid productId, UpdateProductCommand model)
    {
        model.ProductId = productId;
        await Mediator.Send(model);
        return Ok();
    }

    /// <summary>
    /// Delete product from the inventory
    /// </summary>
    /// <param name="productId"></param>
    /// <returns></returns>
    [HttpDelete]
    [Route("{productId}")]
    [ApiPermissionFilter(RoleTypes.ProductDelete)]
    public async Task<IActionResult> Delete(Guid productId)
    {
        await Mediator.Send(new DeleteProductCommand(productId));
        return Ok();
    }
}
