﻿using eMart.API.Controllers.Base;
using eMart.API.Filters;
using eMart.Application.Features.Orders.Commands;
using eMart.Application.Features.Orders.Queries;
using eMart.Application.Features.Orders.Queries.Models;
using Microsoft.AspNetCore.Mvc;

namespace eMart.API.Controllers;

/// <summary>
/// Manage Orders
/// </summary>
public class OrderController : ApiControllerBase
{
    /// <summary>
    /// get user all orders
    /// </summary>
    /// <returns></returns>
    [HttpGet]
    [ApiPermissionFilter]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<OrderViewModel>))]
    public async Task<IActionResult> Get()
    {
        var orders = await Mediator.Send(new UserOrderListQuery());
        return Ok(orders);
    }

    /// <summary>
    /// get user order by Id
    /// </summary>
    /// <param name="OrderId"></param>
    /// <returns></returns>
    [HttpGet]
    [Route("{OrderId}")]
    [ApiPermissionFilter]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(OrderViewModel))]
    public async Task<IActionResult> Get(Guid OrderId)
    {
        var order = await Mediator.Send(new UserOrderByIdQuery(OrderId));
        return Ok(order);
    }

    /// <summary>
    /// Checkout
    /// </summary>
    /// <param name="model"></param>
    /// <returns></returns>
    [HttpPost]
    [Route("CheckOut")]
    [ApiPermissionFilter]
    public async Task<IActionResult> CheckOut(CheckoutCommand model)
    {
        await Mediator.Send(model);
        return Ok();
    }
}
