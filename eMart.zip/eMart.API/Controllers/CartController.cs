﻿using eMart.API.Controllers.Base;
using eMart.API.Filters;
using eMart.Application.Features.Carts.Commands;
using eMart.Application.Features.Carts.Queries;
using eMart.Application.Features.Carts.Queries.Models;
using Microsoft.AspNetCore.Mvc;

namespace eMart.API.Controllers;

/// <summary>
/// Manage Cart
/// </summary>
[ApiPermissionFilter]
public class CartController : ApiControllerBase
{
    /// <summary>
    /// get user cart 
    /// </summary>
    /// <returns></returns>
    [HttpGet]
    [ApiPermissionFilter]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CartViewModel))]
    public async Task<IActionResult> Get()
    {
        var cart = await Mediator.Send(new CartQuery());
        return Ok(cart);
    }

    /// <summary>
    /// Add product to the cart
    /// </summary>
    /// <param name="model"></param>
    /// <returns></returns>
    [HttpPost]
    [ApiPermissionFilter]
    public async Task<IActionResult> Post(AddItemCommand model)
    {
        await Mediator.Send(model);
        return Ok();
    }

    /// <summary>
    /// Update product in the cart
    /// </summary>
    /// <returns></returns>
    [HttpPut]
    [ApiPermissionFilter]
    public async Task<IActionResult> Put(UpdateItemCommand model)
    {
        await Mediator.Send(model);
        return Ok();
    }

    /// <summary>
    /// Delete product from the cart
    /// </summary>
    /// <param name="productId"></param>
    /// <returns></returns>
    [HttpDelete]
    [ApiPermissionFilter]
    public async Task<IActionResult> Delete(Guid productId)
    {
        await Mediator.Send(new DeleteItemCommand(productId));
        return Ok();
    }
}
