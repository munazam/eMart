﻿using eMart.API.Controllers.Base;
using eMart.Application.Features.Account.Commands;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace eMart.API.Controllers
{
    /// <summary>
    /// Authentication Managment
    /// </summary>
    /// 
    [AllowAnonymous]
    public class AccountController : ApiControllerBase
    {

        /// <summary>
        /// Authenticate the user by (username and password) with grant oauth token.
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("Token")]
        public async Task<IActionResult> Token([FromForm] TokenCommand command)
        {
            var token = await Mediator.Send(command);
            return Ok(token);
        }

        /// <summary>
        /// Authenticate the user by refresh token
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("RefreshToken")]
        public async Task<IActionResult> RefreshToken([FromForm] RefreshTokenCommand command)
        {
            var token = await Mediator.Send(command);
            return Ok(token);
        }

        /// <summary>
        /// register user for ordering
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("Register")]
        public async Task<IActionResult> Register(RegisterCommand command)
        {
            await Mediator.Send(command);
            return Ok();
        }
    }
}
