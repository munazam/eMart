﻿using eMart.API.Filters;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace eMart.API.Controllers.Base
{
    /// <summary>
    /// 
    /// </summary>
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    [ApiExceptionFilter]
    //[ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
    //[ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(ProblemDetails))]
    //[ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(ValidationProblemDetails))]
    //[ProducesResponseType(StatusCodes.Status404NotFound)]
    //[ProducesResponseType(StatusCodes.Status200OK)]
    //[ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public abstract class ApiControllerBase : ControllerBase
    {
        private ISender _mediator;
        /// <summary>
        /// 
        /// </summary>
        protected ISender Mediator => _mediator ??= HttpContext.RequestServices.GetRequiredService<ISender>();
    }
}