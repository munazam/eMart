﻿using eMart.Application.Common.Exceptions;
using eMart.Domain.Exceptions;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using NLog;
using System.Net;
using static System.Net.Mime.MediaTypeNames;

namespace eMart.API.Middlewares
{
    /// <summary>
    /// 
    /// </summary>
    public static class ExceptionsHandlerMiddleware
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static Action<IApplicationBuilder> HandleApplicationExceptions()
        {
            return exceptionHandlerApp => exceptionHandlerApp.Run(async context => await HandleException(context));
        }

        private static async Task HandleException(HttpContext context)
        {
            var exceptionHandler = context.Features.Get<IExceptionHandlerFeature>();

            if (exceptionHandler != null && exceptionHandler.Error != null)
            {
                var response = context.Response;
                response.ContentType = "application/json";

                string message;

                switch (exceptionHandler.Error)
                {
                    case BusinessException businessException:

                        response.StatusCode = StatusCodes.Status400BadRequest;
                        var details = new ProblemDetails()
                        {
                            Detail = businessException.Message,
                            Type = "https://tools.ietf.org/html/rfc7231#section-6.5.1"
                        };
                        message = JsonConvert.SerializeObject(details);
                        break;

                    case NotFoundException notFoundException:

                        response.StatusCode = StatusCodes.Status404NotFound;
                        message = JsonConvert.SerializeObject(notFoundException.Message);
                        break;

                    case UnAuthorizeException _:

                        response.StatusCode = StatusCodes.Status401Unauthorized;
                        message = JsonConvert.SerializeObject(HttpStatusCode.Unauthorized.ToString());
                        break;

                    default:
                        var logger = LogManager.GetCurrentClassLogger();
                        logger.Error(exceptionHandler.Error);

                        response.StatusCode = StatusCodes.Status500InternalServerError;
                        message = JsonConvert.SerializeObject(exceptionHandler.Error.Message);
                        break;
                }

                await response.WriteAsync(message);
            }
            else
            {
                context.Response.StatusCode = StatusCodes.Status500InternalServerError;

                context.Response.ContentType = Text.Plain;

                await context.Response.WriteAsync("An exception was thrown.");
            }
        }
    }
}
