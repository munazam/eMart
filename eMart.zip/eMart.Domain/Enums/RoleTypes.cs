﻿namespace eMart.Domain.Enums
{
    public enum RoleTypes
    {
        UserLogView,
        UserView,
        UserCreate,
        UserUpdate,
        UserDelete,
        TodoItemView,
        TodoItemCreate,
        TodoItemUpdate,
        TodoItemDelete,
        ProductCreate,
        ProductUpdate,
        ProductDelete
    }
}