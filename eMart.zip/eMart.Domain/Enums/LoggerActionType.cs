﻿using System.ComponentModel;

namespace eMart.Domain.Enums
{
    public enum LoggerActionType
    {
        [Description("Login")]
        Login,
        [Description("Register")]
        Register,
        [Description("Create User")]
        CreateUser,
        [Description("Update User")]
        UpdateUser,
        [Description("Activate User")]
        ActivateUser,
        [Description("Deactivate User")]
        DeactivateUser,
        [Description("Create Cart")]
        CreateCart,
        [Description("Create Cart Item")]
        CreateCartItem,
        [Description("Update Cart Item")]
        UpdateCartItem,
        [Description("Create Product")]
        CreateProduct,
        [Description("Update Product")]
        UpdateProduct,
        [Description("Delete Product")]
        DeleteProduct,
        [Description("CheckOut")]
        CheckOut,
    }
}
