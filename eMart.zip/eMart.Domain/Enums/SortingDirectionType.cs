﻿namespace eMart.Domain.Enums
{
    public enum SortingDirectionType
    {
        Ascending,
        Descending
    }
}