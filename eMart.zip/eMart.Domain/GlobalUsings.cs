﻿global using eMart.Domain.Entities;
global using eMart.Domain.Entities.Base;
global using eMart.Domain.Enums;
global using eMart.Domain.Events;
global using eMart.Domain.Events.UserEvents;
global using eMart.Domain.Exceptions;
global using MediatR;
global using System.ComponentModel.DataAnnotations.Schema;
