﻿namespace eMart.Domain.Entities;
public class OrderItem
{
    private OrderItem()
    {
            
    }

    public OrderItem(Product product, int quantity)
    {
        OrderItemId = Guid.NewGuid();
        Product = product;
        Quantity = quantity;
        ProductName = Product.Name;
        Price = Product.Price;

        ValidateQuantity();
    }

    public Guid OrderItemId { get; private set; }
    public Guid ProductId { get; private set; }
    public Product Product { get; private set; }
    public int Quantity { get; private set; }
    public string ProductName { get; private set; }
    public decimal Price { get; private set; }

    private void ValidateQuantity()
    {
        if (Product.Quantity < Quantity)
            throw new BusinessException($"Only {Product.Quantity} items are available");
    }
}
