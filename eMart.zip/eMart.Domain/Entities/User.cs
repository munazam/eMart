﻿using Microsoft.AspNetCore.Identity;

namespace eMart.Domain.Entities;

public class User : IdentityUser<Guid>
{
    #region Constuctors

    private User()
    {

    }

    public User(string userName, string fullName, string email, string phoneNumber) : base(userName)
    {
        FullName = fullName;
        Email = email;
        PhoneNumber = phoneNumber;
        IsActive = true;
        IsDeleted = false;
        CreationDateTime = DateTime.Now;
        LastModifiedDateTime = CreationDateTime;

        AddDomainEvent(new UserRegisterEvent(this));

    }

    #endregion

    #region Properties

    public string FullName { get; private set; }

    public bool IsActive { get; private set; }

    public bool IsDeleted { get; private set; }

    public DateTime CreationDateTime { get; private set; }

    public DateTime LastModifiedDateTime { get; private set; }

    public DateTime? LastLoginDateTime { get; private set; }

    public Cart Cart { get; private set; }

    private readonly List<UserRefreshToken> _refreshTokens = [];
    public IReadOnlyCollection<UserRefreshToken> RefreshTokens => _refreshTokens.AsReadOnly();

    #endregion

    #region Methods

    public void MarkAsLoggedIn()
    {
        if (IsActive == false)
            throw new BusinessException("User is not active");

        LastLoginDateTime = DateTime.Now;
        LockoutEnd = null;

        AddDomainEvent(new UserLoginEvent(this));
    }

    public bool IsLockedOut()
    {
        return LockoutEnd.HasValue && LockoutEnd >= DateTime.Now.ToUniversalTime();
    }

    public void Activate(string actionReason = null)
    {
        IsActive = true;
        LastModifiedDateTime = DateTime.Now;

        AddDomainEvent(new ActivateUserEvent(this, actionReason));
    }

    public void Deactivate(string actionReason = null)
    {
        IsActive = false;
        LastModifiedDateTime = DateTime.Now;

        AddDomainEvent(new DeactivateUserEvent(this, actionReason));
    }

    public void MarkAsLogin()
    {
        LastLoginDateTime = DateTime.Now;

        AddDomainEvent(new UserLoginEvent(this));
    }

    public void Update()
    {
        LastModifiedDateTime = DateTime.Now;

        AddDomainEvent(new UpdateUserEvent(this));
    }
    #endregion

    #region Logger Methods

    private List<INotification> _domainEvents;

    public void AddDomainEvent(INotification eventItem)
    {
        _domainEvents ??= new List<INotification>();
        _domainEvents.Add(eventItem);
    }

    public void RemoveDomainEvent(INotification eventItem)
    {
        _domainEvents?.Remove(eventItem);
    }

    public List<INotification> GetDomainEvents()
    {
        return _domainEvents ?? new List<INotification>();
    }
    #endregion
}
