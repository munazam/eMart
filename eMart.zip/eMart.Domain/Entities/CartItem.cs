﻿namespace eMart.Domain.Entities;
public class CartItem : BaseEntity
{
    private CartItem()
    {
            
    }

    internal CartItem(Product product, int quantity)
    {
        CartItemId = Guid.NewGuid();
        Product = product;
        Quantity = quantity;

        ValidateQuantity();

        AddDomainEvent(new DomainEvent(this, LoggerActionType.CreateCartItem, $"Product '{Product.Name}' with quantity '{Quantity}' added to cart", CartItemId));
    }

    public Guid CartItemId { get; private set; }
    public Guid ProductId { get; private set; }
    public Product Product { get; private set; }
    public int Quantity { get; private set; }

    internal void UpdateQuantity(int newQuantity)
    {
        Quantity = newQuantity;

        ValidateQuantity();

        AddDomainEvent(new DomainEvent(this, LoggerActionType.UpdateCartItem, $"Product '{Product.Name}' quantity updated to '{Quantity}' in the cart", CartItemId));
    }

    private void ValidateQuantity()
    {
        if (Product.Quantity < Quantity)
            throw new BusinessException($"Only {Product.Quantity} items are available");
    }
}
