﻿namespace eMart.Domain.Entities;

public class Product : BaseEntity
{
    private Product()
    {
        
    }

    public Product(string name, string description, decimal price, int quantity)
    {
        ProductId = Guid.NewGuid();
        Name = name;
        Description = description;
        Price = price;
        Quantity = quantity;

        AddDomainEvent(new DomainEvent(this, LoggerActionType.CreateProduct, $"New product '{Name}' with quantity '{Quantity}' added to the inventory", ProductId));
    }

    public Guid ProductId { get; private set; }
    public string Name { get; private set; }
    public string Description { get; private set; }
    public decimal Price { get; private set; }
    public int Quantity { get; private set; }

    public void Update(string name, string description, decimal price, int quantity)
    {
        Name = name;
        Description = description;
        Price = price;
        Quantity = quantity;

        AddDomainEvent(new DomainEvent(this, LoggerActionType.UpdateProduct, $"Product '{Name}' with quantity '{Quantity}' updated in the inventory", ProductId));
    }

    public void Delete()
    {
        IsDeleted = true;

        AddDomainEvent(new DomainEvent(this, LoggerActionType.DeleteProduct, $"Product '{Name}' with quantity '{Quantity}' deleted from the inventory", ProductId));
    }
}
