﻿namespace eMart.Domain.Entities;

public class ActionLog
{
    public long ActionLogId { get; private set; }

    public string Username { get; private set; }

    public LoggerActionType Action { get; private set; }

    public string Message { get; private set; }

    public string Details { get; private set; }

    public DateTime CreationDateTime { get; private set; }

}
