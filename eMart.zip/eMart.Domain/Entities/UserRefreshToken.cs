﻿namespace eMart.Domain.Entities;

public class UserRefreshToken
{
    #region Constructors
    private UserRefreshToken()
    {
    }

    public UserRefreshToken(Guid userId, int refreshTokenLifeTime)
    {
        UserRefreshTokenId = Guid.NewGuid();
        UserId = userId;
        ProtectedTicket = GenerateRandomTicket();
        IssuedUtc = DateTime.UtcNow;
        ExpiresUtc = DateTime.UtcNow.AddMinutes(refreshTokenLifeTime);
    }

    #endregion

    #region Properties

    public Guid UserRefreshTokenId { get; private set; }

    public Guid UserId { get; private set; }

    public DateTime IssuedUtc { get; private set; }

    public DateTime ExpiresUtc { get; private set; }

    public string ProtectedTicket { get; private set; }

    public User User { get; set; }
    #endregion

    private string GenerateRandomTicket()
    {
        return $"{Guid.NewGuid()}{Guid.NewGuid()}".Replace("-", "");

    }
}