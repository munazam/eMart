﻿using Microsoft.AspNetCore.Identity;

namespace eMart.Domain.Entities;

public class Role : IdentityRole<Guid>
{

    private Role()
    {

    }
    public Role(string name)
    {
        Id = Guid.NewGuid();
        Name = name;
        NormalizedName = name.ToUpper();
        ConcurrencyStamp = Guid.NewGuid().ToString();
    }
}