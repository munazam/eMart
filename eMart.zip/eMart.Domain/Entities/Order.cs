﻿namespace eMart.Domain.Entities;
public class Order : BaseEntity
{
    private Order()
    {

    }
    public Order(Cart cart, List<Guid> selectedProductIds, string addressName, string mobileNumber, string addressLine1, string addressLine2)
    {
        OrderId = Guid.NewGuid();
        User = cart.User;
        AddressName = addressName;
        MobileNumber = mobileNumber;
        AddressLine1 = addressLine1;
        AddressLine2 = addressLine2;

        MoveItemToOrder(cart, selectedProductIds);

        AddDomainEvent(new DomainEvent(this, LoggerActionType.CheckOut, $"Order initialized for user '{User.UserName}'", OrderId));
    }

    public Guid OrderId { get; private set; }
    public Guid UserId { get; private set; }
    public User User { get; private set; }
    public decimal Shipping { get; private set; }
    public decimal Tax { get; private set; }

    public string AddressName { get; private set; }
    public string MobileNumber { get; private set; }
    public string AddressLine1 { get; private set; }
    public string AddressLine2 { get; private set; }
    public decimal Total { get; private set; }

    private readonly List<OrderItem> _orderItems = [];
    public IEnumerable<OrderItem> OrderItems => _orderItems.AsReadOnly();

    private void MoveItemToOrder(Cart cart, List<Guid> selectedProductIds)
    {
        var selectedCartItems = cart.CartItems.Where(c => selectedProductIds.Contains(c.ProductId)).ToList();

        foreach (var cartItem in selectedCartItems)
            _orderItems.Add(new OrderItem(cartItem.Product, cartItem.Quantity));

        cart.RemoveCartItems(selectedCartItems);

        Total = _orderItems.Sum(s => s.Price * s.Quantity);
        Tax = (16 * Total) / 100; // flat 16 percent tax
        Shipping = 200; //Fixed shipment charges
    }
}
