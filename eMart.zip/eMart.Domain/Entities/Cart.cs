﻿namespace eMart.Domain.Entities;
public class Cart : BaseEntity
{
    private Cart()
    {

    }
    public Cart(User user)
    {
        CartId = Guid.NewGuid();
        User = user;

        AddDomainEvent(new DomainEvent(this, LoggerActionType.CreateCart, $"Cart initialized for user '{user.UserName}'", CartId));
    }

    public Guid CartId { get; private set; }
    public Guid UserId { get; private set; }
    public User User { get; private set; }

    private readonly List<CartItem> _cartItems = [];
    public IEnumerable<CartItem> CartItems => _cartItems.AsReadOnly();

    public void Add(Product product, int quantity)
    {
        var cartItem = _cartItems.FirstOrDefault(c => c.ProductId == product.ProductId);

        if (cartItem != null)
            cartItem.UpdateQuantity(cartItem.Quantity + quantity);
        else
            _cartItems.Add(new CartItem(product, quantity));
    }

    public void UpdateProductQuantity(Product product, int quantity)
    {
        var cartItem = _cartItems.FirstOrDefault(c => c.ProductId == product.ProductId) ?? throw new BusinessException("Product not exists in the cart");

        cartItem.UpdateQuantity(quantity);
    }

    public void Remove(Guid productId)
    {
        var cartItemToRemove = _cartItems.Find(x => x.ProductId == productId);
        _cartItems.Remove(cartItemToRemove);
    }

    internal void RemoveCartItems(IEnumerable<CartItem> selectedCartItems)
    {
        foreach (var item in selectedCartItems)
        {
            _cartItems.Remove(item);
        }
    }
}
