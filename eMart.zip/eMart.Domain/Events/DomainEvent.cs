﻿namespace eMart.Domain.Events
{
    [NotMapped]
    public class DomainEvent : INotification
    {
        public DomainEvent(BaseEntity entity, LoggerActionType actionType, string actionMessage, Guid key)
        {
            Key = key;
            Entity = entity;
            ActionType = actionType;
            ActionMessage = actionMessage;
        }

        public Guid Key { get; private set; }

        public BaseEntity Entity { get; private set; }

        public LoggerActionType ActionType { get; private set; }

        public string ActionMessage { get; private set; }
    }
}
