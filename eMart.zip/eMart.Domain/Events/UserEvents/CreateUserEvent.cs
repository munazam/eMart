﻿namespace eMart.Domain.Events.UserEvents
{
    public class CreateUserEvent : INotification
    {
        public CreateUserEvent(User user)
        {
            User = user;
        }

        public User User { get; private set; }
    }
}
