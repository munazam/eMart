﻿namespace eMart.Domain.Events.UserEvents
{
    public class DeactivateUserEvent : INotification
    {
        public DeactivateUserEvent(User user, string actionReason)
        {
            User = user;
            ActionReason = actionReason;
        }

        public User User { get; private set; }

        public string ActionReason { get; private set; }
    }
}
