﻿namespace eMart.Domain.Events.UserEvents
{
    public class UserLoginEvent : INotification
    {
        public UserLoginEvent(User user)
        {
            User = user;
        }

        public User User { get; private set; }
    }

}
