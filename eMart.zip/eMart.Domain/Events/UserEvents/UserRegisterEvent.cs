﻿namespace eMart.Domain.Events.UserEvents
{
    public class UserRegisterEvent : INotification
    {
        public UserRegisterEvent(User user)
        {
            User = user;
        }

        public User User { get; private set; }
    }

}
