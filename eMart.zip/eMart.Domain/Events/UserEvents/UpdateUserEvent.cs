﻿namespace eMart.Domain.Events.UserEvents
{
    public class UpdateUserEvent : INotification
    {
        public UpdateUserEvent(User user)
        {
            User = user;
        }

        public User User { get; private set; }
    }
}
