﻿namespace eMart.Domain.Events.UserEvents
{
    public class ActivateUserEvent : INotification
    {
        public ActivateUserEvent(User user, string actionReason)
        {
            User = user;
            ActionReason = actionReason;
        }

        public User User { get; private set; }

        public string ActionReason { get; private set; }
    }
}
