# eMart

## Description
Welcome! This is a test project

## Instructions
1. Create db named eMart in sql server database
2. Configure the ConnectionStrings in appsettings of eMart.API project
3. Set eMart.API as startup project
4. Open Package Manager Console and set the default project to eMart.Infrastructure
5. Run command in Package Manager Console "Update-Database"
6. Run application and swagger landing page will show 
7. Admin credentials: Username: admin, Password: P@ssw0rd
8. User admin user to manage products
9. Normal user can register using the register api from Account Section in swagger