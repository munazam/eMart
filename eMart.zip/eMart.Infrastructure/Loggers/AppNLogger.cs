﻿using eMart.Application.Interfaces;
using eMart.Domain.Enums;
using NLog;

namespace eMart.Infrastructure.Loggers
{
    public class AppNLogger : IAppNLogger
    {
        private readonly Logger _logger;

        public AppNLogger()
        {
            _logger = LogManager.GetCurrentClassLogger();
        }

        public void Log(LoggerActionType actionType, string message, string anonymousUsername = null, string details = null, Guid? key = null)
        {
            var theEvent = new LogEventInfo
            {
                Level = LogLevel.Info,
                Message = message,
            };

            theEvent.Properties["Key"] = key;
            theEvent.Properties["Details"] = details;
            theEvent.Properties["Action"] = actionType.ToString();
            theEvent.Properties["AnonymousUsername"] = anonymousUsername;

            _logger.Log(theEvent);
        }
    }
}