﻿using eMart.Application.Interfaces;
using eMart.Domain.Entities.Base;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace eMart.Infrastructure.Persistence.Interceptors
{
    public class AuditableEntitySaveChangesInterceptor : SaveChangesInterceptor
    {
        private readonly IAccountService _accountService;

        public AuditableEntitySaveChangesInterceptor(
            IAccountService accountService)
        {
            _accountService = accountService;
        }

        public override InterceptionResult<int> SavingChanges(DbContextEventData eventData, InterceptionResult<int> result)
        {
            UpdateEntities(eventData.Context);

            return base.SavingChanges(eventData, result);
        }

        public override ValueTask<InterceptionResult<int>> SavingChangesAsync(DbContextEventData eventData, InterceptionResult<int> result, CancellationToken cancellationToken = default)
        {
            UpdateEntities(eventData.Context);

            return base.SavingChangesAsync(eventData, result, cancellationToken);
        }

        public void UpdateEntities(DbContext context)
        {
            const string isDeletedColumnName = "IsDeleted";
            if (context == null) return;

            var userName = "admin";

            userName = _accountService.GetLoggedInUserName();
            if (userName == string.Empty) // in case of seeding data username will be empty
                userName = "admin";

            var now = DateTime.Now;

            foreach (var entry in context.ChangeTracker.Entries<BaseEntity>())
            {
                if (entry.State == EntityState.Added)
                {
                    entry.Entity.CreatedBy = userName;
                    entry.Entity.Created = now;
                }

                if (entry.State == EntityState.Deleted && entry.Properties.Any(p => p.Metadata.Name == isDeletedColumnName))
                {
                    entry.State = EntityState.Modified;
                    entry.CurrentValues[isDeletedColumnName] = true;
                }

                if (entry.State == EntityState.Added || entry.State == EntityState.Modified || entry.HasChangedOwnedEntities())
                {
                    entry.Entity.LastModifiedBy = userName;
                    entry.Entity.LastModified = now;
                }


            }
        }
    }

    public static class Extensions
    {
        public static bool HasChangedOwnedEntities(this EntityEntry entry) =>
            entry.References.Any(r =>
                r.TargetEntry != null &&
                r.TargetEntry.Metadata.IsOwned() &&
                (r.TargetEntry.State == EntityState.Added || r.TargetEntry.State == EntityState.Modified));
    }
}
