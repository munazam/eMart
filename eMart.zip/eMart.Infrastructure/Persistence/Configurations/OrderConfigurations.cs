﻿using eMart.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace eMart.Infrastructure.Persistence.Configurations;
internal class OrderConfiguration : IEntityTypeConfiguration<Order>
{
    public void Configure(EntityTypeBuilder<Order> builder)
    {
        builder.Property(x => x.OrderId).ValueGeneratedNever();

        builder.Property(x => x.AddressName).IsRequired(true).HasMaxLength(250);
        builder.Property(x => x.MobileNumber).IsRequired(true).HasMaxLength(20);
        builder.Property(x => x.AddressLine1).IsRequired(true).HasMaxLength(500);

        builder.Property(x => x.Total).HasColumnType("decimal(18, 4)");
        builder.Property(x => x.Shipping).HasColumnType("decimal(18, 4)");
        builder.Property(x => x.Tax).HasColumnType("decimal(18, 4)");
    }
}

internal class OrderItemConfiguration : IEntityTypeConfiguration<OrderItem>
{
    public void Configure(EntityTypeBuilder<OrderItem> builder)
    {
        builder.Property(x => x.OrderItemId).ValueGeneratedNever();

        builder.Property(x => x.Price).HasColumnType("decimal(18, 4)");
    }
}
