﻿using eMart.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace eMart.Infrastructure.Persistence.Configurations;
internal class ProductConfiguration : IEntityTypeConfiguration<Product>
{
    public void Configure(EntityTypeBuilder<Product> builder)
    {
        builder.Property(x => x.ProductId).ValueGeneratedNever();

        builder.Property(x => x.Name).IsRequired(true).HasMaxLength(250);
        
        builder.Property(x => x.Price).HasColumnType("decimal(18, 4)");
    }
}
