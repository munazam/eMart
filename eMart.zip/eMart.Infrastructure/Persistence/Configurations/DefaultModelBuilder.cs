﻿using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace eMart.Infrastructure.Persistence.Configurations;

internal class DefaultModelBuilder
{
    public static void ApplyConfiguration(ModelBuilder modelBuilder)
    {
        UseSoftDeleteQueryFilter(modelBuilder);
    }

    private static void UseSoftDeleteQueryFilter(ModelBuilder modelBuilder)
    {
        const string isDeletedColumn = "IsDeleted";
        foreach (var entityType in modelBuilder.Model.GetEntityTypes())
        {
            if (entityType.FindProperty(isDeletedColumn) == null)
                continue;

            var parameter = Expression.Parameter(entityType.ClrType);
            var propertyMethodInfo = typeof(EF).GetMethod("Property").MakeGenericMethod(typeof(bool));
            var isDeletedProperty = Expression.Call(propertyMethodInfo, parameter, Expression.Constant(isDeletedColumn));

            var compareExpression = Expression.MakeBinary(ExpressionType.Equal, isDeletedProperty, Expression.Constant(false));

            var lambda = Expression.Lambda(compareExpression, parameter);
            modelBuilder.Entity(entityType.ClrType).HasQueryFilter(lambda);
        }
    }
}