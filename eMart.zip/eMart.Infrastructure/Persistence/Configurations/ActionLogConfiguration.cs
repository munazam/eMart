﻿using eMart.Domain.Entities;
using eMart.Domain.Enums;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace eMart.Infrastructure.Persistence.Configurations;

internal class ActionLogConfiguration : IEntityTypeConfiguration<ActionLog>
{
    public void Configure(EntityTypeBuilder<ActionLog> builder)
    {
        builder.ToTable("ActionLogs", "LOG", x => x.ExcludeFromMigrations());
        builder.Property(s => s.Action).HasConversion(new EnumToStringConverter<LoggerActionType>());
    }
}
