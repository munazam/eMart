﻿using eMart.Domain.Entities;
using eMart.Domain.Enums;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace eMart.Infrastructure.Persistence
{
    public class ApplicationDbContextInitialiser
    {
        private readonly ILogger<ApplicationDbContextInitialiser> _logger;
        private readonly ApplicationDbContext _context;
        private readonly UserManager<User> _userManager;
        private readonly RoleManager<Role> _roleManager;

        public ApplicationDbContextInitialiser(ILogger<ApplicationDbContextInitialiser> logger, ApplicationDbContext context, UserManager<User> userManager, RoleManager<Role> roleManager)
        {
            _logger = logger;
            _context = context;
            _userManager = userManager;
            _roleManager = roleManager;
        }

        public async Task InitialiseAsync()
        {
            try
            {
                if (_context.Database.IsSqlServer())
                {
                    await _context.Database.MigrateAsync();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while initialising the database.");
                throw;
            }
        }

        public async Task SeedAsync()
        {
            try
            {
                await TrySeedAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while seeding the database.");
                throw;
            }
        }

        public async Task TrySeedAsync()
        {
            //this is just demo, remove in production release
            await SeedRoleData();
            await SeedUserData();
        }

        private async Task SeedUserData()
        {
            var administrator = new User("admin", "Administrator", null, null);

            if (_userManager.Users.All(u => u.UserName != administrator.UserName))
            {
                await _userManager.CreateAsync(administrator, "P@ssw0rd");
                await _userManager.AddToRolesAsync(administrator, Enum.GetNames(typeof(RoleTypes)));
            }
        }

        private async Task SeedRoleData()
        {
            foreach (var roleName in Enum.GetNames(typeof(RoleTypes)))
            {
                if (!_roleManager.Roles.Any(r => r.Name == roleName))
                    await _roleManager.CreateAsync(new Role(roleName));
            }
        }
    }
}